python arena.py checkpoints-limited 4 7
